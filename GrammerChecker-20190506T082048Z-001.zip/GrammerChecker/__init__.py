#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 16:49:19 2019

@author: snayak1
"""

from .articleErrorDector import articleErrorDector
from .tenseErrorDetector import tenseErrorDetector
